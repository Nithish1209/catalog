import { Injectable } from '@angular/core';
import { Point } from '../models/test-case.model';

@Injectable({
  providedIn: 'root'
})
export class PolynomialService {
  decodeValue(value: string, base: string): bigint {
    return BigInt(parseInt(value, parseInt(base)));
  }

  // Lagrange interpolation to find constant term
  findConstantTerm(points: Point[]): bigint {
    let result = BigInt(0);
    
    for (let i = 0; i < points.length; i++) {
      let term = points[i].y;
      let numerator = BigInt(1);
      let denominator = BigInt(1);
      
      for (let j = 0; j < points.length; j++) {
        if (i !== j) {
          numerator *= BigInt(-points[j].x);
          denominator *= BigInt(points[i].x - points[j].x);
        }
      }
      
      // Multiply by the term
      result += (term * numerator) / denominator;
    }
    
    return result;
  }
}
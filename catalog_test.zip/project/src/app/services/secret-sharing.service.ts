import { Injectable } from '@angular/core';
import { TestCase, Point } from '../models/test-case.model';
import { PolynomialService } from './polynomial.service';

@Injectable({
  providedIn: 'root'
})
export class SecretSharingService {
  constructor(private polynomialService: PolynomialService) {}

  solveTestCase(testCase: TestCase): bigint {
    const k = testCase.keys.k;
    const points: Point[] = [];
    
    // Get first k points
    let count = 0;
    for (const [key, value] of Object.entries(testCase)) {
      if (key !== 'keys' && count < k) {
        const x = parseInt(key);
        const y = this.polynomialService.decodeValue(
          value.value,
          value.base
        );
        points.push({ x, y });
        count++;
      }
    }

    return this.polynomialService.findConstantTerm(points);
  }
}
export interface TestCase {
  keys: {
    n: number;
    k: number;
  };
  [key: string]: {
    base: string;
    value: string;
  } | any;
}

export interface Point {
  x: number;
  y: bigint;
}